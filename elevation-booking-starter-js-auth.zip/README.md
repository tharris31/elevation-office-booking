# Elevation Office Booking — JavaScript Starter (with Login)

## 1) Supabase — Create tables (paste in SQL Editor)

```sql
-- SCHEMA
create table if not exists public.locations (
  id bigserial primary key,
  created_at timestamptz not null default now(),
  name text not null unique
);

create table if not exists public.rooms (
  id bigserial primary key,
  created_at timestamptz not null default now(),
  name text not null,
  location_id bigint not null references public.locations(id) on delete cascade
);

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  created_at timestamptz not null default now(),
  email text unique,
  role text check (role in ('Admin Manager','Admin Assistant','Therapist')) default 'Therapist'
);

create table if not exists public.bookings (
  id bigserial primary key,
  created_at timestamptz not null default now(),
  room_id bigint not null references public.rooms(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  start_time timestamptz not null,
  end_time timestamptz not null,
  notes text
);

-- useful indexes
create index if not exists idx_bookings_room_time on public.bookings(room_id, start_time, end_time);

-- RLS
alter table public.locations enable row level security;
alter table public.rooms enable row level security;
alter table public.profiles enable row level security;
alter table public.bookings enable row level security;

-- Policies: allow authenticated users to read base tables
create policy "locations_read_auth" on public.locations
for select using (auth.role() = 'authenticated');

create policy "rooms_read_auth" on public.rooms
for select using (auth.role() = 'authenticated');

create policy "profiles_self_read" on public.profiles
for select using (auth.uid() = id);

create policy "bookings_read_auth" on public.bookings
for select using (auth.role() = 'authenticated');

-- Write policies (simple: allow authenticated to insert/update/delete bookings)
create policy "bookings_write_auth" on public.bookings
for all using (auth.role() = 'authenticated') with check (auth.role() = 'authenticated');
```

Then: Table Editor → `profiles` → add a row for each staff member (id match their auth user id after first login).

## 2) Supabase — Turn on Email/Password
Authentication → Providers → Email: enable.

## 3) Add staff
Authentication → Users → Add user (email + temp password).

## 4) GitHub → Upload this project
Create a repo and upload all files in this folder.

## 5) Vercel
- Import the repo. Framework Preset: **Next.js**
- Environment variables:
  - `NEXT_PUBLIC_SUPABASE_URL` = Project URL
  - `NEXT_PUBLIC_SUPABASE_ANON_KEY` = anon public key
- Deploy.
- Open your domain → You'll see a **/login** page. Sign in with the user you added.
```)

